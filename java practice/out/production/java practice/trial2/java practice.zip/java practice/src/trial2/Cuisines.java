package trial2;

public interface Cuisines {
    double chinese();

    double indian();

    double italian();
}
