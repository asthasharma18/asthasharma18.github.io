package trial2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MealChoices implements Cuisines {
    double cost=0.0;
    List<String> items= new ArrayList<>();
    @Override
    public  double chinese(){
        System.out.println("Select from the given menu:");
        System.out.println("Press 1 for regular meal");
        System.out.println("Press 2 for jumbo meal");
        Scanner scanner=new Scanner(System.in);
        int a= scanner.nextInt();
        if(a==1){
            items.add("REGULAR MEAL(CHINESE)                120");
            cost+=120.0;
        }
        else if (a==2){
            items.add("JUMBO MEAL(CHINESE)                  200");
            cost+=200.0;
        }else {
            System.out.println("OPTION NOT AVAILABLE");
        }
        return cost;
    }

    @Override
    public double indian() {
        System.out.println("Select from the given menu:");
        System.out.println("Press 1 for regular meal");
        System.out.println("Press 2 for jumbo meal");
        Scanner scanner=new Scanner(System.in);
        int a= scanner.nextInt();
        if(a==1){
            items.add("REGULAR MEAL(INDIAN)                 100");
            cost+=100.0;
        }
        else if (a==2){
            items.add("JUMBO MEAL(INDIAN)                   180");
            cost+=180.0;
        }else {
            System.out.println("OPTION NOT AVAILABLE");
        }
        return cost;
    }

    @Override
    public double italian() {
        System.out.println("Select from the given menu:");
        System.out.println("Press 1 for regular meal");
        System.out.println("Press 2 for jumbo meal");
        Scanner scanner=new Scanner(System.in);
        int a= scanner.nextInt();
        if(a==1){
            items.add("REGULAR MEAL(ITALIAN)                150");
            cost+=100.0;
        }
        else if (a==2){
            items.add("JUMBO MEAL(ITALIAN)                  200");
            cost+=180.0;
        }else {
            System.out.println("OPTION NOT AVAILABLE");
        }
        return cost;
    }

}
